var app = angular.module("habitApp", ["ngRoute"]);

app.config(function ($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "views/home.html",
            controller: "HomeController"
        })
        .when("/habits", {
            templateUrl: "views/habits.html",
            controller: "HabitController"
        })
        .when("/goals", {
            templateUrl: "views/goals.html",
            controller: "GoalController"
        })
        .when("/about", {
            templateUrl: "views/about.html"
        })
        .otherwise({
            redirectTo: "/"
        });
});


app.controller("HomeController", function ($scope, HabitService) {
    $scope.habits = HabitService.getHabits();
    $scope.goals = HabitService.getGoals();
});



app.controller("HabitController", function ($scope, HabitService) {
    $scope.habits = HabitService.getHabits();
    $scope.newHabit = {
        category: "Health",
        priority: "Medium"
    };
    $scope.addHabit = function () {
        if (!$scope.newHabit.name) return;
        HabitService.addHabit({
            name: $scope.newHabit.name,
            category: $scope.newHabit.category,
            priority: $scope.newHabit.priority,
            completed: false
        });
        $scope.newHabit = {
            category: "Health",
            priority: "Medium"
        };
    };  
    $scope.deleteHabit=function(index){
        if(confirm("Delete this habit?")){
            HabitService.deleteHabit(index);
        }
    }
    $scope.toggleStatus = function(habit){
        HabitService.toggleHabit(habit);
    };
    $scope.editIndex = -1;
    $scope.editHabit = function(index){
        $scope.editIndex = index;
        $scope.newHabit = angular.copy($scope.habits[index]);
    };
    $scope.updateHabit = function(){
        $scope.habits[$scope.editIndex] = angular.copy($scope.newHabit);
        localStorage.setItem("habits", JSON.stringify($scope.habits));
        $scope.newHabit = {
            category:"Health",
            priority:"Medium"
        };
        $scope.editIndex = -1;
    };
});


app.controller("HomeController", function ($scope, HabitService) {
    $scope.habits = HabitService.getHabits();
    $scope.goals = HabitService.getGoals();
    // Habit Statistics
    $scope.totalHabits = $scope.habits.length;
    $scope.completedHabits = $scope.habits.filter(function(h){
        return h.completed;
    }).length;
    $scope.pendingHabits = $scope.totalHabits - $scope.completedHabits;
    // Goal Progress
    $scope.totalGoalProgress = function(){
        if($scope.goals.length === 0)
            return 0;
        var total = 0;
        $scope.goals.forEach(function(goal){
            total += (goal.progress / goal.target) * 100;
        });
        return Math.round(total / $scope.goals.length);
    };
    // Daily Quotes
    var quotes = [
        "Small habits make big differences.",
        "Success starts with consistency.",
        "Never skip twice.",
        "Progress is better than perfection.",
        "Discipline beats motivation."
    ];
    $scope.todayQuote = quotes[Math.floor(Math.random()*quotes.length)];
});

app.controller("GoalController", function ($scope, HabitService) {
    $scope.goals = HabitService.getGoals();
    $scope.newGoal = {};
    $scope.addGoal = function () {
        if (!$scope.newGoal.title || !$scope.newGoal.target)
            return;
        HabitService.addGoal({
            title: $scope.newGoal.title,
            target: Number($scope.newGoal.target),
            progress: 0
        });
        $scope.newGoal = {};
    };
    $scope.deleteGoal = function (index) {
        HabitService.deleteGoal(index);
    };
    $scope.updateProgress = function () {
        HabitService.saveGoals();
    };
});