app.service("HabitService", function () {
    var habits = JSON.parse(localStorage.getItem("habits")) || [];
    var goals = JSON.parse(localStorage.getItem("goals")) || [];
    function saveHabits() {
        localStorage.setItem("habits", JSON.stringify(habits));
    }
    function saveGoals() {
        localStorage.setItem("goals", JSON.stringify(goals));
    }
    // ---------------- HABITS ----------------
    this.getHabits = function () {
        return habits;
    };
    this.addHabit = function (habit) {
        habits.push(habit);
        saveHabits();
    };
    this.deleteHabit = function (index) {
        habits.splice(index, 1);
        saveHabits();
    };
    this.toggleHabit = function (habit) {
        habit.completed = !habit.completed;
        saveHabits();
    };
    // ---------------- GOALS ----------------
    this.getGoals = function () {
        return goals;
    };
    this.addGoal = function (goal) {
        goals.push(goal);
        saveGoals();
    };
    this.deleteGoal = function (index) {
        goals.splice(index, 1);
        saveGoals();
    };
    this.saveGoals = function () {
        saveGoals();
    };
});